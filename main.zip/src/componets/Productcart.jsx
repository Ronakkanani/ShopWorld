import React, { useEffect, useState } from 'react'
import axios from 'axios';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';
import { FaStar } from "react-icons/fa";
import { AiOutlineStock } from "react-icons/ai";
import { Link, useParams } from 'react-router-dom';

export default function Productcart({ search }) {

    const [productcard, setProductcard] = useState(null);
    const [serachcard, setSerachcard] = useState(null);
    const { title } = useParams();
    const [pagi, setPagi] = useState(0);

    // const dispatch = useDispatch();

    // const Additem = (item) => {
    //     dispatch(Addcart(item))
    // }

    useEffect(() => {
        // setTimeout(() => {
        let url
        if (title?.length > 0) {
            url = `https://dummyjson.com/products/category/${title}` // spafic catagory
        } else {
            url = `https://dummyjson.com/products?limit=6&skip=${pagi}` //all catagory
        }
        axios({
            method: 'get',
            url: url,
        })
            .then(function (response) {
                setSerachcard(response.data.products)
                setProductcard(response.data.products)
                // console.log('card', response);
            });
        // }, 1000)
    }, [title, pagi]);

    useEffect(() => {
        if (serachcard != null) {

            let filterdata = productcard.filter((item) => {
                return item.title.includes(search)
            });
            setSerachcard(filterdata)
        }
    }, [search]);

    console.log('product', productcard);

    const nextbtn = () => {
        if (pagi == 96) {
            setPagi(0);
        } else {
            setPagi(pagi + 6);
        }
        console.log('pagi', pagi);
    }

    const prebtn = () => {
        if (pagi >= 6) {
            setPagi(pagi - 6);
        }
    }
    return (
        <>
            {
                productcard == null
                    ?
                    <div className="loders d-flex justify-content-center align-items-center">
                        <div class="spinner1">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                    </div>
                    :
                    serachcard.map((item, index) => {
                        return (
                            <div className="col-lg-4 col-md-6">
                                <Card className='cardRight p-0 '>
                                    <Link to={`/detail/${item.id}`}>
                                        <Card.Img variant="top" src={item.thumbnail} loading='lazy' />
                                        <Card.Body>
                                            <Card.Title>{item.title}</Card.Title>
                                            <Card.Text>{item.description}</Card.Text>
                                            <div className='d-flex justify-content-between'>
                                                <p style={{ color: 'green', fontWeight: 'bold' }}>Price : ${item.price}</p>
                                                <span className='text-black' style={{ fontWeight: 'normal' }}>{item.discountPercentage}%off</span>
                                                <span className='stock'><AiOutlineStock /> {item.stock} </span>
                                            </div>

                                        </Card.Body>
                                    </Link>
                                    {/* <div className='right_card_icon d-flex align-items-center justify-content-between'>
                                        <span className='star'>{item.rating}<FaStar /></span>
                                        <Button onClick={()=>dispatch(Addcart(item))}>Add Cart</Button>
                                        <Button>Buy Now</Button>
                                    </div> */}
                                </Card>
                            </div >
                        )
                    })
            }
            <div className='d-flex justify-content-center'>
                <button onClick={prebtn} className='btn btn-info mx-1' disabled={pagi == 0}>Prev</button>
                <button onClick={nextbtn} className='btn btn-primary'>Next</button>
            </div>
        </>
    )
}
