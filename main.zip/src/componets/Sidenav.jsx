import React, { useEffect, useState } from 'react'
import axios from 'axios';
import Spinner from 'react-bootstrap/Spinner';
import { Link } from 'react-router-dom';

export default function Sidenav() {

    const [sidenav, setSidenav] = useState(null);

    useEffect(() => {
        // setTimeout(() => {
        axios({
            method: 'get',
            url: 'https://dummyjson.com/products/categories',
        })
        .then(function (response) {
                // console.log('value', response)
                setSidenav(response.data)
            });
        // }, 1000);
    }, [])

    return (
        <>
            <div className="slidenav">
                <ul>
                    {
                        sidenav == null
                            ?
                            ''
                            :
                            <>
                                <Link className='nav-link' to={`/`}> <li className='px-2'> All category</li></Link>
                                {
                                    sidenav.map((item, index) => {
                                        return (
                                            <Link className='nav-link' to={`/${item}`}> <li key={index} className='px-2'>{item}</li></Link>
                                        )
                                    })
                                }
                            </>

                    }
                </ul>
            </div>
        </>
    )
}
